﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using Wordle_hw.EF;

namespace Wordle_hw
{
    public partial class Form1 : Form
    {
        private enum PageState
        {
            Description,
            Login,
            Register
        }

        private PageState _currentPage = PageState.Description;
        private Users _currentUser = null;

        public Form1()
        {
            InitializeComponent();
            ShowDescriptionPage();
        }

        #region Page Navigation

        private void ShowDescriptionPage()
        {
            _currentPage = PageState.Description;

            // Hide all panels first
            pnlDescription.Visible = true;
            pnlLogin.Visible = false;
            pnlRegister.Visible = false;

            // Update UI based on login status
            if (_currentUser == null)
            {
                btnLogout.Visible = false;
                lblWelcomeUser.Visible = false;
                btnLoginRegister.Visible = true;
            }
            else
            {
                btnLogout.Visible = true;
                lblWelcomeUser.Visible = true;
                lblWelcomeUser.Text = $"Welcome, {_currentUser.UserName}!";
                btnLoginRegister.Visible = false;
            }
        }

        private void ShowLoginPage()
        {
            _currentPage = PageState.Login;

            // Hide all panels first
            pnlDescription.Visible = false;
            pnlLogin.Visible = true;
            pnlRegister.Visible = false;

            // Clear any previous login info
            txtLoginEmail.Clear();
            txtLoginPassword.Clear();
            lblLoginError.Visible = false;
        }

        private void ShowRegisterPage()
        {
            _currentPage = PageState.Register;

            // Hide all panels first
            pnlDescription.Visible = false;
            pnlLogin.Visible = false;
            pnlRegister.Visible = true;

            // Clear any previous registration info
            txtRegisterUsername.Clear();
            txtRegisterEmail.Clear();
            txtRegisterPassword.Clear();
            lblRegisterError.Visible = false;
        }

        #endregion

        #region Button Click Events

        private void btnLoginRegister_Click(object sender, EventArgs e)
        {
            ShowLoginPage();
        }

        private void lnkCreateAccount_Click(object sender, EventArgs e)
        {
            ShowRegisterPage();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string email = txtLoginEmail.Text.Trim();
            string password = txtLoginPassword.Text;

            // Validate inputs
            if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(password))
            {
                lblLoginError.Text = "Please enter both email and password.";
                lblLoginError.Visible = true;
                return;
            }

            // Authenticate user
            using (var context = new DataModelContainer())
            {
                var user = context.Users.FirstOrDefault(u => u.Email == email && u.Password == password);

                if (user != null)
                {
                    _currentUser = user;
                    ShowDescriptionPage();
                }
                else
                {
                    lblLoginError.Text = "Invalid email or password.";
                    lblLoginError.Visible = true;
                }
            }
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            string username = txtRegisterUsername.Text.Trim();
            string email = txtRegisterEmail.Text.Trim();
            string password = txtRegisterPassword.Text;

            // Validate inputs
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(email) || string.IsNullOrEmpty(password))
            {
                lblRegisterError.Text = "Please fill in all fields.";
                lblRegisterError.Visible = true;
                return;
            }

            // Validate email format
            if (!IsValidEmail(email))
            {
                lblRegisterError.Text = "Please enter a valid email address.";
                lblRegisterError.Visible = true;
                return;
            }

            // Validate password strength
            if (password.Length < 6)
            {
                lblRegisterError.Text = "Password must be at least 6 characters long.";
                lblRegisterError.Visible = true;
                return;
            }

            // Check if email already exists
            using (var context = new DataModelContainer())
            {
                if (context.Users.Any(u => u.Email == email))
                {
                    lblRegisterError.Text = "Email address is already registered.";
                    lblRegisterError.Visible = true;
                    return;
                }

                if (context.Users.Any(u => u.UserName == username))
                {
                    lblRegisterError.Text = "Username is already taken.";
                    lblRegisterError.Visible = true;
                    return;
                }

                // Create new user
                var newUser = new Users
                {
                    UserName = username,
                    Email = email,
                    Password = password,
                    Created_at = DateTime.Now
                };

                context.Users.Add(newUser);
                context.SaveChanges();

                // Auto-login the new user
                _currentUser = newUser;
                ShowDescriptionPage();
            }
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            _currentUser = null;
            ShowDescriptionPage();
        }

        private void lnkBackToLogin_Click(object sender, EventArgs e)
        {
            ShowLoginPage();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            ShowDescriptionPage();
        }

        #endregion

        #region Helper Methods

        private bool IsValidEmail(string email)
        {
            // Simple regex for email validation
            string pattern = @"^[^@\s]+@[^@\s]+\.[^@\s]+$";
            return Regex.IsMatch(email, pattern);
        }

        #endregion
    }
}